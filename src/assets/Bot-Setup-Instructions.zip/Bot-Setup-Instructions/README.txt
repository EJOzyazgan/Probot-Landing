Thank You for participating in the Probot Playground AI Competition.

BOTS:  
All bots must be written in python. The bots will be running in an anaconda environment, so all anaconda packages are available for your use. If there is a package that you really need is not available let us know at team@probotplayground.com and we will review it. 
Example bots have been provided in the file bot_methods.py.
These bots demonstrate the varying actions your bot can take form folding, calling, and raising. 

Your bot will have 5 seconds to return its action. Failure to return in 5 seconds or to return data in the wrong format will result in an automatic fold for the current hand. 

DATA:

The data your bot receives will be a JSON object consisting of a �state� and �history�. The �state� is a JSON object of the current state of the game. The �history� is an array of JSON objects representing all the past states of the game. 

An example of the game data received is provided in the game-state-data.txt. The data is in a string format, so you may wish to prettify it for easier reading. 

This example is a response that was send during the last hand of a game, so there is the full history. Earlier hands will not have as much history. 


If you have any questions regarding your bot or the data, please contact us at team@probotplayground.com
